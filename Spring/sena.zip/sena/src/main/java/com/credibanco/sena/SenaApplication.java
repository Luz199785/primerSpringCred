package com.credibanco.sena;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SenaApplication {

	public static void main(String[] args) {
		SpringApplication.run(SenaApplication.class, args);
	}

}
