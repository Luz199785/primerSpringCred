package com.example.Luz;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LuzApplicationTests {

	@Test
	void contextLoads() {
	}

}
